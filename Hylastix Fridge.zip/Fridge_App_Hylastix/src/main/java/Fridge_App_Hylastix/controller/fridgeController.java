package Fridge_App_Hylastix.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.core.Authentication;

import Fridge_App_Hylastix.entity.fridgeCapacityInfo;
import Fridge_App_Hylastix.entity.fridgeProduct;
import Fridge_App_Hylastix.service.fridgeProductService;

@Controller
@RequestMapping("/fridgeApp")
public class fridgeController {
	
	
	
	
	@Autowired
    private fridgeProductService service;
	
	
	
	
		
	

   //HOME PAGE
	@GetMapping("/home")
    public String home(Model model) {
		
		model.addAttribute("fridgeProducts", service.getAllProducts()); 
		model.addAttribute("expiringFridgeProducts", service.getExpiringProducts(3));
		model.addAttribute("expiredProducts", service.getExpiredProducts());
		model.addAttribute("totalProducts", service.getTotalQuantity());
		model.addAttribute("eatenProducts", service.getLastFiveEatenProducts());
		
		
		fridgeCapacityInfo capacity = service.calculateCurrentCapacity();
		model.addAttribute("capacity", capacity);


        return "fridge-main-paige";
    }

	
	//CREATE PRODUCT
	@PostMapping("/add")
	public String addProduct(@RequestParam String productName,
	                         @RequestParam int quantity,
	                         @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate expiryDate,
	                         @RequestParam String category,
	                         @RequestParam String unit,
	                         RedirectAttributes redirectAttributes,
	                         Authentication authentication) {
		
		

		 //  Check role permission
        if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            redirectAttributes.addFlashAttribute("errorMessage", "🔒 You do not have permission to add a product.Only an admin can perform this action.");
          
            return "redirect:/fridgeApp/home";
        }
		

	    if (expiryDate.isBefore(LocalDate.now())) {
	    	
	        redirectAttributes.addFlashAttribute("errorMessage", "Expiration date cannot be in the past!");
	        
	        return "redirect:/fridgeApp/home";

	    }

	    	    
	    if (service.isDuplicateProductName(productName)) {
	    	
	        redirectAttributes.addFlashAttribute("errorMessage", "Product with this name already exists in the fridge!");
	       
	        return "redirect:/fridgeApp/home";
	    }

	    
	 // ✅ VALIDATE UNIT BASED ON CATEGORY
	    if ((category.equals("Fruit") || category.equals("Vegetable") || category.equals("Canned") || category.equals("Eggs")) && !unit.equals("Piece")) {
	        redirectAttributes.addFlashAttribute("errorMessage", "❌ Invalid unit for selected category! Only 'Piece' is allowed.");
	        return "redirect:/fridgeApp/home";
	    }


	    if (category.equals("Drink") && !(unit.equals("Liter") || unit.equals("Glass"))) {
	        redirectAttributes.addFlashAttribute("errorMessage", "❌ Invalid unit for Drink! Only 'Liter' or 'Glass' are allowed.");
	        return "redirect:/fridgeApp/home";
	    }
	    
	    if (category.equals("Eggs") && !(unit.equals("Piece"))) {
	        redirectAttributes.addFlashAttribute("errorMessage", "❌ Invalid unit for Eggs! Only 'Piece' are allowed.");
	        return "redirect:/fridgeApp/home";
	    }
	    	    
	    fridgeCapacityInfo capacity = service.calculateCurrentCapacity();
	    
	    int newQty = quantity;
	    
	    String unitLower = unit.toLowerCase();

	    if (unitLower.equals("piece") && capacity.getTotalPieces() + newQty > 50) {
	        redirectAttributes.addFlashAttribute("errorMessage", "⚠️ Maximum of 50 pieces reached!");
	        return "redirect:/fridgeApp/home";
	    }

	    if (unitLower.equals("liter") && capacity.getTotalLiters() + newQty > 10) {
	        redirectAttributes.addFlashAttribute("errorMessage", "⚠️ Maximum of 10 liters reached!");
	        return "redirect:/fridgeApp/home";
	    }

	    if (unitLower.equals("glass") && capacity.getTotalGlasses() + newQty > 10) {
	        redirectAttributes.addFlashAttribute("errorMessage", "⚠️ Maximum of 10 glasses reached!");
	        return "redirect:/fridgeApp/home";
	    }

	    // Enforce logic that if piece is full, no liters/glasses can be added
	    if ((unitLower.equals("liter") || unitLower.equals("glass")) && capacity.getTotalPieces() >=70) {
	        redirectAttributes.addFlashAttribute("errorMessage", "⚠️ You can't add liters/glasses while piece capacity is full!");
	        return "redirect:/fridgeApp/home";
	    }

	    fridgeProduct product = new fridgeProduct();
	    product.setProductName(productName);
	    product.setQuantity(quantity);
	    product.setExpiryDate(expiryDate);
	    product.setCategory(category);
	    product.setUnit(unit);
	    product.setFridgeEntryTime(LocalDate.now());

	    service.saveProduct(product);
	    redirectAttributes.addFlashAttribute("successMessage", "Product is successfully added in fridge!");

	    
	    return "redirect:/fridgeApp/home";

	}




    
    //DELETE PRODUCT
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id,Authentication authentication, RedirectAttributes redirectAttributes) {
    	
    	 if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
             redirectAttributes.addFlashAttribute("errorMessage", "🔒You do not have permission to delete the product. Only an admin can perform this action.");
             
             return "redirect:/fridgeApp/home";
         }
    	
        service.deleteProduct(id);
        redirectAttributes.addFlashAttribute("successMessage", " You have successfully deleted the product.");

        
        return "redirect:/fridgeApp/home";

    }
    
    
    //EAT PRODUCT
    @GetMapping("/eat/{id}")
    public String eatProduct(@PathVariable Long id,RedirectAttributes redirectAttributes) {
        fridgeProduct product = service.getProductById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

        // Create EatenProduct and save it to history
        service.saveEatenProduct(product.getProductName(),
                                       product.getQuantity(),
                                       product.getExpiryDate(),
                                       LocalDate.now());

        // Delete from the fridge
        service.deleteProduct(id);
        redirectAttributes.addFlashAttribute("successMessage", "🍽 You have successfully eaten the product!");

        return "redirect:/fridgeApp/home";

    }


    
    
   // Display the form for editing a product.
    @GetMapping("/edit/{id}")
    public String editProduct(@PathVariable Long id, Model model,Authentication authentication, RedirectAttributes redirectAttributes) {
    	
    	if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            redirectAttributes.addFlashAttribute("errorMessage", "🔒 You do not have permission to edit the product.Only an admin can perform this action.");
            return "redirect:/fridgeApp/home";
        }
    	
    	fridgeProduct product = service.getProductById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
        
        model.addAttribute("fridgeProduct", product);
        
        return "edit-fridge-product";
    }

   
    //UPDATE PRODUCT
    @PostMapping("/update/{id}")
    public String updateProduct(@PathVariable Long id,
                                @RequestParam String productName,
                                @RequestParam int quantity,
                                @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate expiryDate ,Authentication authentication,
                                RedirectAttributes redirectAttributes) {
    	
    	
    	 if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
             redirectAttributes.addFlashAttribute("errorMessage", "🔒 You do not have permission to edit the product.Only an admin can perform this action.");
             return "redirect:/fridgeApp/home";
         }

        fridgeProduct updatedProduct = service.getProductById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));

        updatedProduct.setProductName(productName);
        updatedProduct.setQuantity(quantity);
        updatedProduct.setExpiryDate(expiryDate);

        service.saveProduct(updatedProduct);
        redirectAttributes.addFlashAttribute("successMessage", " Product updated successfully!");

        return "redirect:/fridgeApp/home";

    }
    
    
    @GetMapping("/filterByStatus")
    public String filterByStatus(@RequestParam("status") String status, Model model) {
    	
        List<fridgeProduct> filteredProducts;

        LocalDate today = LocalDate.now();

        switch (status) {
            case "ok":
                filteredProducts = service.getAllProducts().stream()
                    .filter(p -> p.getExpiryDate().isAfter(today.plusDays(2)))
                    .collect(Collectors.toList());
                break;
            case "expiring":
                filteredProducts = service.getAllProducts().stream()
                    .filter(p -> !p.getExpiryDate().isBefore(today) &&
                                 p.getExpiryDate().isBefore(today.plusDays(3)))
                    .collect(Collectors.toList());
                break;
            case "expired":
                filteredProducts = service.getAllProducts().stream()
                    .filter(p -> p.getExpiryDate().isBefore(today))
                    .collect(Collectors.toList());
                break;
            default:
                filteredProducts = service.getAllProducts();
        }

        model.addAttribute("fridgeProducts", filteredProducts);
        model.addAttribute("totalProducts", service.getTotalQuantity());
        model.addAttribute("capacity", service.calculateCurrentCapacity());
        model.addAttribute("expiredProducts", service.getExpiredProducts());
        model.addAttribute("expiringFridgeProducts", service.getExpiredProducts());
        model.addAttribute("eatenProducts", service.getEatenProducts());

        return "fridge-main-paige"; 
    }

    
    
    @GetMapping("/form")
    public String showForm(@RequestParam(required = false) String category,
                           Model model,
                           Authentication authentication) {
        
        System.out.println("USER ROLES = " + authentication.getAuthorities());

        model.addAttribute("selectedCategory", category);

        List<String> units = switch (category != null ? category : "") {
            case "Drink" -> List.of("Glass", "Liter");
            case "Eggs" -> List.of("Piece");
            case "Milk" -> List.of("Liter", "Glass", "Piece");
            case "Fruit", "Vegetable", "Canned" -> List.of("Piece");
            default -> List.of();
        };

        model.addAttribute("units", units);
        
        return "fridge-main-paige"; 
    }




}



