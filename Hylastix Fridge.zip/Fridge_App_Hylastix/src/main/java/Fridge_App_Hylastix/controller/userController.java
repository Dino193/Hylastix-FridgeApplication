package Fridge_App_Hylastix.controller;


import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import Fridge_App_Hylastix.entity.security.User;
import Fridge_App_Hylastix.repository.UserRepository;
import Fridge_App_Hylastix.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;




@Controller
@RequestMapping("/users")
@Tag(name = "Tasks", description = "Endpoints for managing users.")
public class userController {
	
	
	
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private UserService userService;

   
    
    
    /**
     * 1) List all users (ADMIN only) - "user-list.html"
     */
    @GetMapping
    public String getAllUsers(Authentication auth, Model model) {
    	
        User currentUser = userService.findByEmail(auth.getName());

        // Check if user is admin
        if (!currentUser.getRoles().contains("ROLE_ADMIN")) {
            return "error-403"; // render 403 page
        }

        List<User> allUsers = userRepo.findAll();
        
        model.addAttribute("users", allUsers);
        
        return "user-list";
    }

   
    
    
    /**
     * 2) Get user by ID (ADMIN or the user) - "user-detail.html"
     */
    @GetMapping("/{id}")
    public String getUserById(@PathVariable Long id, Authentication auth, Model model) {
    	
        User currentUser = userService.findByEmail(auth.getName());
        
        User targetUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Only admin or the same user can view this
        if (!currentUser.getRoles().contains("ROLE_ADMIN") &&
            !targetUser.getId().equals(currentUser.getId())) {
            return "error-403";
        }

        model.addAttribute("user", targetUser);
        
        return "user-detail";
    }
    
    

    /**
     * 3) Admin: Show form to update user roles - "edit-roles.html"
     */
    @GetMapping("/{id}/edit-roles")
    public String editRolesForm(@PathVariable Long id, Authentication auth, Model model) {
        User currentUser = userService.findByEmail(auth.getName());
        if (!currentUser.getRoles().contains("ROLE_ADMIN")) {
            return "error-403";
        }

        User targetUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        model.addAttribute("user", targetUser);
        return "edit-roles";
    }
    
    
    

    /**
     * 4) Admin: Update user roles (handles form submission)
     */
    @PostMapping("/{id}/edit-roles")
    public String updateRoles(
            @PathVariable Long id,
            @RequestParam("role") String role,
            Authentication auth,
            Model model
    ) {
        User currentUser = userService.findByEmail(auth.getName());
        if (!currentUser.getRoles().contains("ROLE_ADMIN")) {
            return "error-403";
        }

        User targetUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        targetUser.setRoles(Set.of(role));
        userRepo.save(targetUser);

        model.addAttribute("message", "Updated role for user: " + targetUser.getEmail());
        return "redirect:/users";
    }

    
    
	/**
	 * 5) Admin: Delete user by ID
	 */
	@PostMapping("/{id}/delete")
	public String deleteUser(@PathVariable Long id, Authentication auth, Model model,RedirectAttributes redirectAttributes) {

		User currentUser = userService.findByEmail(auth.getName());

		// Only admins can delete users
		if (!currentUser.getRoles().contains("ROLE_ADMIN")) {
			return "error-403";
		}

		User userToDelete = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));

		
		// ❌ Prevent admin from deleting themselves
	    if (userToDelete.getId().equals(currentUser.getId())) {
	        redirectAttributes.addFlashAttribute("message", "❌ You cannot delete your own account.");
	        return "redirect:/users";
	    }

	    // ❌ Prevent deletion of other admins
	    if (userToDelete.getRoles().contains("ROLE_ADMIN")) {
	        redirectAttributes.addFlashAttribute("message", "❌ You cannot delete another admin.");
	        return "redirect:/users";
	    }
		
		
	

		userRepo.delete(userToDelete);
		model.addAttribute("message", "User " + userToDelete.getEmail() + " has been deleted.");
		return "redirect:/users";
	}
	
	
	
   

	/**
	 * 6) Admin: Toggle block/unblock for a user (except other admins)
	 */
	@PostMapping("/{id}/toggle-block")
	public String toggleBlockUser(@PathVariable Long id, Authentication auth, RedirectAttributes redirectAttributes) {
	    User currentUser = userService.findByEmail(auth.getName());

	    // Only admin can block/unblock
	    if (!currentUser.getRoles().contains("ROLE_ADMIN")) {
	        return "error-403";
	    }

	    User userToToggle = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));

	    // Prevent blocking another admin
	    if (userToToggle.getRoles().contains("ROLE_ADMIN")) {
	        redirectAttributes.addFlashAttribute("errorMessage", "❌ You cannot block or unblock another admin.");
	        return "redirect:/users";
	    }

	    boolean currentlyEnabled = userToToggle.isEnabled();
	    userToToggle.setEnabled(!currentlyEnabled); // toggle

	    userRepo.save(userToToggle);

	    String status = currentlyEnabled ? "blocked" : "unblocked";
	    redirectAttributes.addFlashAttribute("successMessage", "✅ User " + userToToggle.getEmail() + " has been " + status + ".");
	    
	    return "redirect:/users";
	}


   
}


