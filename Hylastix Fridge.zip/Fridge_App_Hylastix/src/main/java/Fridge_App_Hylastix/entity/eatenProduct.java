package Fridge_App_Hylastix.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "eaten_product")
public class eatenProduct {
	
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(name = "product_name")
	    private String productName;

	    @Column(name = "quantity")
	    private int quantity;

	    @Column(name = "expiry_date")
	    private LocalDate expiryDate;

	    @Column(name = "eaten_date")
	    private LocalDate eatenDate;

	    public eatenProduct() {}

	    public eatenProduct(String productName, int quantity, LocalDate expiryDate, LocalDate eatenDate) {
	        this.productName = productName;
	        this.quantity = quantity;
	        this.expiryDate = expiryDate;
	        this.eatenDate = eatenDate;
	    }

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public LocalDate getExpiryDate() {
			return expiryDate;
		}

		public void setExpiryDate(LocalDate expiryDate) {
			this.expiryDate = expiryDate;
		}

		public LocalDate getEatenDate() {
			return eatenDate;
		}

		public void setEatenDate(LocalDate eatenDate) {
			this.eatenDate = eatenDate;
		}

		@Override
		public String toString() {
			return "eatenProduct [id=" + id + ", productName=" + productName + ", quantity=" + quantity
					+ ", expiryDate=" + expiryDate + ", eatenDate=" + eatenDate + "]";
		}
	    
	    
	    
}
