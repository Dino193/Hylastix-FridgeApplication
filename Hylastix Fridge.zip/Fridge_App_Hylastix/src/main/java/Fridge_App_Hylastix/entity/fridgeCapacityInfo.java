package Fridge_App_Hylastix.entity;

public class fridgeCapacityInfo {
	
	
	 private int totalPieces;
	 
	 private int totalGlasses;
	 
	 private int totalLiters;

	
	 
	 public fridgeCapacityInfo() {
		
	}



	public fridgeCapacityInfo(int totalPieces, int totalGlasses, int totalLiters) {
		super();
		this.totalPieces = totalPieces;
		this.totalGlasses = totalGlasses;
		this.totalLiters = totalLiters;
	}



	public int getTotalPieces() {
		return totalPieces;
	}



	public void setTotalPieces(int totalPieces) {
		this.totalPieces = totalPieces;
	}



	public int getTotalGlasses() {
		return totalGlasses;
	}



	public void setTotalGlasses(int totalGlasses) {
		this.totalGlasses = totalGlasses;
	}



	public int getTotalLiters() {
		return totalLiters;
	}



	public void setTotalLiters(int totalLiters) {
		this.totalLiters = totalLiters;
	}



	@Override
	public String toString() {
		return "fridgeCapacityInfo [totalPieces=" + totalPieces + ", totalGlasses=" + totalGlasses + ", totalLiters="
				+ totalLiters + ", getTotalPieces()=" + getTotalPieces() + ", getTotalGlasses()=" + getTotalGlasses()
				+ ", getTotalLiters()=" + getTotalLiters() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	 
	 
	 
	 
	 
	 
	 

}
