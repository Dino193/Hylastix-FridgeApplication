package Fridge_App_Hylastix.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "fridgeProduct")
public class fridgeProduct {
	
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;

	@Column(name = "productName")
    private String productName;
    
	@Column(name = "quantity")
    private int quantity;

	@Column(name = "fridge_entry_time ")
    private LocalDate fridgeEntryTime;

	//In expiry date we do not allowed NUL for safety of our costumer
	@Column(name = "expiry_date ", nullable = false)
	private LocalDate expiryDate;
	
	@Column(name = "category",nullable = false)
	private String category;
	
	@Column(name = "unit", nullable = false)
	private String unit;
	

	public fridgeProduct() {
		
        this.fridgeEntryTime = LocalDate.now();
    }


	public fridgeProduct(String productName, int quantity, LocalDate fridgeEntryTime, LocalDate expiryDate,
			String category, String unit) {
		super();
		this.productName = productName;
		this.quantity = quantity;
		this.fridgeEntryTime = fridgeEntryTime;
		this.expiryDate = expiryDate;
		this.category = category;
		this.unit = unit;
	}


	public Long getProductId() {
		return productId;
	}


	public void setProductId(Long productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public LocalDate getFridgeEntryTime() {
		return fridgeEntryTime;
	}


	public void setFridgeEntryTime(LocalDate fridgeEntryTime) {
		this.fridgeEntryTime = fridgeEntryTime;
	}


	public LocalDate getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getUnit() {
		return unit;
	}


	public void setUnit(String unit) {
		this.unit = unit;
	}


	@Override
	public String toString() {
		return "fridgeProduct [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity
				+ ", fridgeEntryTime=" + fridgeEntryTime + ", expiryDate=" + expiryDate + ", category=" + category
				+ ", unit=" + unit + "]";
	}

    
	

}