package Fridge_App_Hylastix.entity.security;

public enum Role {
	ROLE_ADMIN,
    ROLE_USER
}
