package Fridge_App_Hylastix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Fridge_App_Hylastix.entity.eatenProduct;

public interface eatenProductRepository extends JpaRepository<eatenProduct, Long> {
	
    List<eatenProduct> findAllByOrderByEatenDateDesc();
}
