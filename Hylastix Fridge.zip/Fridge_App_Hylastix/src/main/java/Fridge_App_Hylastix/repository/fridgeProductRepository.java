package Fridge_App_Hylastix.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import Fridge_App_Hylastix.entity.fridgeProduct;

public interface fridgeProductRepository extends JpaRepository<fridgeProduct, Long> {
	

	/* Retrieves all fridge products from the database, sorted by their expiry date in ascending order. 
	 * * Useful for displaying items in the order of expiration.*/
	 List<fridgeProduct> findAllByOrderByExpiryDateAsc();
    
    /* Finds all fridge products whose expiry date falls within the specified date range
     * * Commonly used for finding items that are about to expire within the next few days*/
    List<fridgeProduct> findByExpiryDateBetween(LocalDate start, LocalDate end);
    
    /**
     * Finds all fridge products that have already expired (i.e., expiry date is before today).
     * Useful for alerting the user or listing expired products.
     **/
    List<fridgeProduct> findByExpiryDateBefore(LocalDate date);
}
