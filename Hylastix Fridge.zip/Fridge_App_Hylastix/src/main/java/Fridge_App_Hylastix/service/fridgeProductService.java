package Fridge_App_Hylastix.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Fridge_App_Hylastix.entity.eatenProduct;
import Fridge_App_Hylastix.entity.fridgeCapacityInfo;
import Fridge_App_Hylastix.entity.fridgeProduct;
import Fridge_App_Hylastix.repository.eatenProductRepository;
import Fridge_App_Hylastix.repository.fridgeProductRepository;

@Service
public class fridgeProductService {
	
	

    @Autowired
    private fridgeProductRepository repository;
    
    @Autowired
    private eatenProductRepository eatenRepo;
    
    
  

    

    public List<fridgeProduct> getAllProducts() {
    	
        return repository.findAllByOrderByExpiryDateAsc();
    }

    
    public fridgeProduct saveProduct(fridgeProduct product) {
    	
        return repository.save(product);
    }

    
    public void deleteProduct(Long id) {
    	
        repository.deleteById(id);
    }
    

    public List<fridgeProduct> getExpiringProducts(int days) {
    	
        LocalDate today = LocalDate.now();
        
        return repository.findByExpiryDateBetween(today, today.plusDays(days));
    }


    public Optional<fridgeProduct> getProductById(Long id) {
    	
        return repository.findById(id);
    }

	
    public List<fridgeProduct> getExpiredProducts() {
    	
        return repository.findByExpiryDateBefore(LocalDate.now());
    }
    
    
    public List<fridgeProduct> getOkProducts() {
    	
        LocalDate today = LocalDate.now();
        
        return repository.findAll().stream()
                .filter(p -> !p.getExpiryDate().isBefore(today) && !p.getExpiryDate().isBefore(today.plusDays(3)))
                .toList();
    }

    
   // Total quantity of all items in the fridge
    public int getTotalQuantity() {
        return repository.findAll()
                         .stream()
                         .mapToInt(fridgeProduct::getQuantity)
                         .sum();
    }
    
    
    //EATEN PRODUCT SERVIC STARTING
    public void eatProduct(Long id) {
        fridgeProduct product = repository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
        
        eatenProduct eaten = new eatenProduct(
            product.getProductName(),
            product.getQuantity(),
            product.getExpiryDate(),
            LocalDate.now()
        );

        eatenRepo.save(eaten);
        repository.deleteById(id);
    }

    public List<eatenProduct> getEatenProducts() {
    	
        return eatenRepo.findAllByOrderByEatenDateDesc();
    }


    public void saveEatenProduct(String productName, int quantity, LocalDate expiryDate, LocalDate eatenDate) {
       
    	eatenProduct eaten = new eatenProduct(productName, quantity, expiryDate, eatenDate);
    	
    	eatenRepo.save(eaten);
    }
    


    //EATEN PRODUCT SERVICE ENDING
    
    
    
    
    // duplicate product name restriction
    public boolean isDuplicateProductName(String productName) {
    	
        return getAllProducts().stream()
            .anyMatch(p -> p.getProductName().equalsIgnoreCase(productName.trim()));
    }
    
    
    //Last 5 eaten products
    public List<eatenProduct> getLastFiveEatenProducts() {
        return eatenRepo.findAllByOrderByEatenDateDesc()
                        .stream()
                        .limit(5)
                        .toList();
    }
    
    
    public fridgeCapacityInfo calculateCurrentCapacity() {
    	
        List<fridgeProduct> all = repository.findAll();

        int pieces = 0;
        int glasses = 0;
        int liters = 0;

        for (fridgeProduct product : all) {
        	
            String unit = product.getUnit().toLowerCase();
            
            int quantity = product.getQuantity();

            switch (unit) {
                case "piece" -> pieces += quantity;
                case "glass" -> glasses += quantity;
                case "liter" -> liters += quantity;
            }
        }

        return new fridgeCapacityInfo(pieces, glasses, liters);
    }


    
    
}
