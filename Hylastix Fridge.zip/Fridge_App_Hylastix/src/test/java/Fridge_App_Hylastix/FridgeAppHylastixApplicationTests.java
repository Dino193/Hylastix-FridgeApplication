package Fridge_App_Hylastix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FridgeAppHylastixApplicationTests {

	@Test
	void contextLoads() {
	}

}
